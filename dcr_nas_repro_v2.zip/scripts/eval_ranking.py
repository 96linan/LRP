import argparse
from dcrnas.config import load_config
from dcrnas.trainer import evaluate_checkpoint

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint", required=True)
    args = parser.parse_args()
    cfg = load_config(args.config)
    evaluate_checkpoint(cfg, args.checkpoint)

if __name__ == "__main__":
    main()
