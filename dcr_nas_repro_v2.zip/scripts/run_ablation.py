import argparse
import copy
from pathlib import Path

from dcrnas.config import load_config, dump_yaml
from dcrnas.trainer import train_main

def build_jobs(base_cfg, ablation):
    jobs = []
    if ablation == "pair_mode":
        for value in ["quantile", "fixed", "random"]:
            cfg = copy.deepcopy(base_cfg)
            cfg["loss"]["pair_mode"] = value
            cfg["output_dir"] = str(Path(base_cfg["output_dir"]).parent / f"ablation_pair_{value}")
            jobs.append((f"pair_mode={value}", cfg))
    elif ablation == "density_mode":
        for value in ["dirichlet", "hist", "uniform"]:
            cfg = copy.deepcopy(base_cfg)
            cfg["loss"]["density_mode"] = value
            cfg["output_dir"] = str(Path(base_cfg["output_dir"]).parent / f"ablation_density_{value}")
            jobs.append((f"density_mode={value}", cfg))
    elif ablation == "gamma_a":
        for value in [0.0, 0.5, 1.0, 1.5, 2.0]:
            cfg = copy.deepcopy(base_cfg)
            cfg["loss"]["gamma_a"] = value
            cfg["output_dir"] = str(Path(base_cfg["output_dir"]).parent / f"ablation_gamma_{str(value).replace('.', '_')}")
            jobs.append((f"gamma_a={value}", cfg))
    elif ablation == "q":
        for value in [0.1, 0.2, 0.3, 0.4]:
            cfg = copy.deepcopy(base_cfg)
            cfg["loss"]["q"] = value
            cfg["output_dir"] = str(Path(base_cfg["output_dir"]).parent / f"ablation_q_{str(value).replace('.', '_')}")
            jobs.append((f"q={value}", cfg))
    else:
        raise ValueError(f"Unknown ablation: {ablation}")
    return jobs

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--ablation", required=True, choices=["pair_mode", "density_mode", "gamma_a", "q"])
    args = parser.parse_args()

    base_cfg = load_config(args.config)
    jobs = build_jobs(base_cfg, args.ablation)

    out_root = Path(base_cfg["output_dir"]).parent
    out_root.mkdir(parents=True, exist_ok=True)

    for name, cfg in jobs:
        cfg_path = out_root / f"tmp_{name.replace('=', '_')}.yaml"
        dump_yaml(cfg, cfg_path)
        print(f"=== Running {name} ===")
        train_main(cfg)

if __name__ == "__main__":
    main()
