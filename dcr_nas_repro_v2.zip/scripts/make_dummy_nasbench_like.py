import argparse
import json
from pathlib import Path
from dcrnas.data.synthetic import generate_synthetic_graph_records

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="data/nasbench_like.json")
    parser.add_argument("--n", type=int, default=2000)
    parser.add_argument("--num_nodes", type=int, default=7)
    parser.add_argument("--node_feat_dim", type=int, default=8)
    args = parser.parse_args()

    records = generate_synthetic_graph_records(
        n=args.n,
        num_nodes=args.num_nodes,
        node_feat_dim=args.node_feat_dim,
        imbalance_strength=3.5,
        noise_std=0.03,
        feature_shift=0.0,
        with_eval_target=True,
    )
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as f:
        json.dump(records, f)
    print(f"Wrote {len(records)} records to {out}")

if __name__ == "__main__":
    main()
