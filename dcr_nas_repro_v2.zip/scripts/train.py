import argparse
from dcrnas.config import load_config
from dcrnas.trainer import train_main

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    cfg = load_config(args.config)
    train_main(cfg)

if __name__ == "__main__":
    main()
