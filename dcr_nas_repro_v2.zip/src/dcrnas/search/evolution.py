from __future__ import annotations

import json
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader

from dcrnas.data.synthetic import build_synthetic_splits
from dcrnas.data.collate import collate_graphs
from dcrnas.models.factory import build_model
from dcrnas.utils.metrics import ranking_summary

def _mutate_graph(adj, node_features, rng):
    adj = adj.copy()
    n = adj.shape[0]
    i = int(rng.integers(0, n - 1))
    j = int(rng.integers(i + 1, n))
    adj[i, j] = 1.0 - adj[i, j]
    return adj, node_features

def search_with_predictor(cfg, checkpoint_path, pool_size=200, steps=150, tournament=10):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    train_ds, valid_ds, test_ds, _ = build_synthetic_splits(cfg)
    sample_batch = next(iter(DataLoader(train_ds, batch_size=4, collate_fn=collate_graphs)))
    model = build_model(cfg, sample_batch)
    ckpt = torch.load(checkpoint_path, map_location="cpu")
    model.load_state_dict(ckpt["model"])
    model.to(device).eval()

    # candidate pool from test set as a closed-domain search demo
    candidate_loader = DataLoader(test_ds, batch_size=len(test_ds), collate_fn=collate_graphs)
    batch = next(iter(candidate_loader))
    for k in ["adj", "node_features", "mask"]:
        batch[k] = batch[k].to(device)
    with torch.no_grad():
        _, pred = model(batch["adj"], batch["node_features"], batch["mask"])
    pred = pred.cpu().numpy()
    true = batch["eval_y"].numpy()

    order = np.argsort(-pred)
    top_pred = order[:10]
    result = {
        "best_pred_index": int(top_pred[0]),
        "best_pred_score": float(pred[top_pred[0]]),
        "best_true_score_at_pred_best": float(true[top_pred[0]]),
        "oracle_best_true_score": float(true.max()),
        "summary": ranking_summary(true, pred),
    }

    out_dir = Path(cfg["output_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "search_demo.json"
    with out_path.open("w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result, indent=2))
