from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Tuple

import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from dcrnas.data.collate import collate_graphs
from dcrnas.data.synthetic import build_synthetic_splits
from dcrnas.data.nasbench_like import build_nasbench_like_splits
from dcrnas.data.augment import augment_graph_batch
from dcrnas.losses.dcr import DCRConfig, DCRLoss
from dcrnas.losses.density import DensityConfig, DensityWeighter
from dcrnas.losses.regression import weighted_huber_loss
from dcrnas.models.factory import build_model
from dcrnas.utils.io import save_json
from dcrnas.utils.logging import CSVLogger, ensure_dir
from dcrnas.utils.metrics import ranking_summary
from dcrnas.utils.seed import set_seed

def build_datasets(cfg):
    name = cfg["dataset"]["name"]
    if name == "synthetic_nas":
        return build_synthetic_splits(cfg)
    if name == "nasbench_like":
        return build_nasbench_like_splits(cfg)
    raise ValueError(f"Unknown dataset name: {name}")

def build_optimizer(cfg, model):
    opt_cfg = cfg["optimizer"]
    if opt_cfg["name"].lower() == "adam":
        return torch.optim.Adam(model.parameters(), lr=opt_cfg["lr"], weight_decay=opt_cfg.get("weight_decay", 0.0))
    raise ValueError(f"Unknown optimizer: {opt_cfg['name']}")

def build_scheduler(cfg, optimizer):
    sch_cfg = cfg.get("scheduler", {})
    if sch_cfg.get("name", "cosine") == "cosine":
        return torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer,
            T_max=sch_cfg.get("t_max", 30),
            eta_min=sch_cfg.get("eta_min", 1e-5),
        )
    return None

def move_batch(batch, device):
    out = dict(batch)
    for k in ["adj", "node_features", "mask", "y", "eval_y"]:
        out[k] = out[k].to(device)
    return out

@torch.no_grad()
def predict_dataset(model, loader, device):
    model.eval()
    y_true, y_eval, y_pred = [], [], []
    ids = []
    for batch in loader:
        batch = move_batch(batch, device)
        _, pred = model(batch["adj"], batch["node_features"], batch["mask"])
        y_true.extend(batch["y"].cpu().numpy().tolist())
        y_eval.extend(batch["eval_y"].cpu().numpy().tolist())
        y_pred.extend(pred.cpu().numpy().tolist())
        ids.extend(batch["id"])
    return {"ids": ids, "y_true": y_true, "y_eval": y_eval, "y_pred": y_pred}

def evaluate_splits(model, valid_loader, test_loader, alt_test_loaders, device):
    valid_pred = predict_dataset(model, valid_loader, device)
    test_pred = predict_dataset(model, test_loader, device)

    metrics = {
        "valid": ranking_summary(valid_pred["y_eval"], valid_pred["y_pred"]),
        "test": ranking_summary(test_pred["y_eval"], test_pred["y_pred"]),
    }
    for name, loader in alt_test_loaders.items():
        pred = predict_dataset(model, loader, device)
        metrics[name] = ranking_summary(pred["y_eval"], pred["y_pred"])
    return metrics

def train_one_epoch(model, train_loader, optimizer, dcr_loss, density_weighter, cfg, device):
    model.train()
    epoch_stats = {"total_loss": 0.0, "reg_loss": 0.0, "dcr_loss": 0.0, "n": 0}

    loss_cfg = cfg["loss"]
    aug_cfg = cfg["augment"]

    for batch in tqdm(train_loader, leave=False):
        batch = move_batch(batch, device)

        adj_a, feat_a = augment_graph_batch(
            batch["adj"], batch["node_features"], batch["mask"],
            edge_drop_prob=aug_cfg.get("edge_drop_prob", 0.1),
            feat_mask_prob=aug_cfg.get("feat_mask_prob", 0.1),
        )
        adj_b, feat_b = augment_graph_batch(
            batch["adj"], batch["node_features"], batch["mask"],
            edge_drop_prob=aug_cfg.get("edge_drop_prob", 0.1),
            feat_mask_prob=aug_cfg.get("feat_mask_prob", 0.1),
        )

        z_a, yhat = model(adj_a, feat_a, batch["mask"])
        z_b, _ = model(adj_b, feat_b, batch["mask"])

        density = density_weighter.compute(batch["y"])
        reg_w = density["reg_w"]
        anchor_eta = density["anchor_eta"]

        reg_loss = weighted_huber_loss(yhat, batch["y"], reg_w, delta=loss_cfg.get("huber_delta", 1.0))
        contrast_loss = dcr_loss(z_a, z_b, batch["y"], yhat, anchor_eta)
        total = loss_cfg.get("alpha", 1.0) * reg_loss + loss_cfg.get("beta", 0.2) * contrast_loss

        optimizer.zero_grad()
        total.backward()
        grad_clip = cfg["training"].get("grad_clip", None)
        if grad_clip is not None:
            torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
        optimizer.step()

        bs = batch["y"].shape[0]
        epoch_stats["total_loss"] += float(total.item()) * bs
        epoch_stats["reg_loss"] += float(reg_loss.item()) * bs
        epoch_stats["dcr_loss"] += float(contrast_loss.item()) * bs
        epoch_stats["n"] += bs

    for k in ["total_loss", "reg_loss", "dcr_loss"]:
        epoch_stats[k] /= max(1, epoch_stats["n"])
    return epoch_stats

def train_main(cfg):
    set_seed(cfg.get("seed", 42))
    out_dir = ensure_dir(cfg["output_dir"])
    device = "cuda" if torch.cuda.is_available() else "cpu"

    train_ds, valid_ds, test_ds, alt_tests = build_datasets(cfg)
    batch_size = cfg["training"]["batch_size"]

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, num_workers=cfg["training"].get("num_workers", 0), collate_fn=collate_graphs)
    valid_loader = DataLoader(valid_ds, batch_size=batch_size, shuffle=False, num_workers=cfg["training"].get("num_workers", 0), collate_fn=collate_graphs)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False, num_workers=cfg["training"].get("num_workers", 0), collate_fn=collate_graphs)
    alt_test_loaders = {
        k: DataLoader(v, batch_size=batch_size, shuffle=False, num_workers=cfg["training"].get("num_workers", 0), collate_fn=collate_graphs)
        for k, v in alt_tests.items()
    }

    sample_batch = next(iter(train_loader))
    model = build_model(cfg, sample_batch).to(device)
    optimizer = build_optimizer(cfg, model)
    scheduler = build_scheduler(cfg, optimizer)

    dcr_cfg = DCRConfig(
        temperature=cfg["loss"].get("temperature", 0.1),
        rho_y=cfg["loss"].get("rho_y", 0.3),
        rho_yhat=cfg["loss"].get("rho_yhat", 0.3),
        pair_mode=cfg["loss"].get("pair_mode", "quantile"),
        bank_size=cfg["loss"].get("bank_size", 1024),
    )
    dcr_loss = DCRLoss(dcr_cfg)

    density_cfg = DensityConfig(
        bins=cfg["loss"].get("bins", 20),
        alpha0=cfg["loss"].get("alpha0", 1.0),
        q=cfg["loss"].get("q", 0.2),
        gamma_reg=cfg["loss"].get("gamma_reg", 1.5),
        gamma_a=cfg["loss"].get("gamma_a", 1.5),
        c_eta=cfg["loss"].get("c_eta", 1.0),
        wmin=cfg["loss"].get("wmin", 0.1),
        wmax=cfg["loss"].get("wmax", 10.0),
        eps=cfg["loss"].get("eps", 1e-8),
        mode=cfg["loss"].get("density_mode", "dirichlet"),
    )
    density_weighter = DensityWeighter(density_cfg)

    logger = CSVLogger(
        out_dir / "train_log.csv",
        fieldnames=[
            "epoch", "train_total_loss", "train_reg_loss", "train_dcr_loss",
            "valid_kendall_tau", "test_kendall_tau", "lr", "timestamp"
        ],
    )

    best_metric = -1e18
    best_path = out_dir / "best.pt"
    last_path = out_dir / "last.pt"

    history = []
    for epoch in range(1, cfg["training"]["epochs"] + 1):
        dcr_loss.reset_bank()
        train_stats = train_one_epoch(model, train_loader, optimizer, dcr_loss, density_weighter, cfg, device)
        if scheduler is not None:
            scheduler.step()

        metrics = evaluate_splits(model, valid_loader, test_loader, alt_test_loaders, device)
        row = {
            "epoch": epoch,
            "train_total_loss": train_stats["total_loss"],
            "train_reg_loss": train_stats["reg_loss"],
            "train_dcr_loss": train_stats["dcr_loss"],
            "valid_kendall_tau": metrics["valid"]["kendall_tau"],
            "test_kendall_tau": metrics["test"]["kendall_tau"],
            "lr": optimizer.param_groups[0]["lr"],
        }
        logger.log(row)
        history.append({"epoch": epoch, "train": train_stats, "metrics": metrics})

        payload = {
            "model": model.state_dict(),
            "config": cfg,
            "epoch": epoch,
            "metrics": metrics,
        }
        torch.save(payload, last_path)
        if metrics["valid"]["kendall_tau"] > best_metric:
            best_metric = metrics["valid"]["kendall_tau"]
            torch.save(payload, best_path)

        print(json.dumps({"epoch": epoch, **row}, indent=2))

    save_json(history, out_dir / "history.json")
    print(f"Best checkpoint: {best_path}")

def evaluate_checkpoint(cfg, checkpoint_path):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    _, valid_ds, test_ds, alt_tests = build_datasets(cfg)
    batch_size = cfg["training"]["batch_size"]

    valid_loader = DataLoader(valid_ds, batch_size=batch_size, shuffle=False, num_workers=cfg["training"].get("num_workers", 0), collate_fn=collate_graphs)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False, num_workers=cfg["training"].get("num_workers", 0), collate_fn=collate_graphs)
    alt_test_loaders = {
        k: DataLoader(v, batch_size=batch_size, shuffle=False, num_workers=cfg["training"].get("num_workers", 0), collate_fn=collate_graphs)
        for k, v in alt_tests.items()
    }

    sample_batch = next(iter(valid_loader))
    model = build_model(cfg, sample_batch).to(device)
    ckpt = torch.load(checkpoint_path, map_location="cpu")
    model.load_state_dict(ckpt["model"])

    metrics = evaluate_splits(model, valid_loader, test_loader, alt_test_loaders, device)
    out_path = Path(cfg["output_dir"]) / "eval_metrics.json"
    save_json(metrics, out_path)
    print(json.dumps(metrics, indent=2))
