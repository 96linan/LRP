from __future__ import annotations

import json
import pickle
from pathlib import Path
from typing import Any

def load_any(path: str | Path) -> Any:
    path = Path(path)
    if path.suffix == ".json":
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    if path.suffix in [".pkl", ".pickle"]:
        with path.open("rb") as f:
            return pickle.load(f)
    raise ValueError(f"Unsupported file format: {path}")

def save_json(obj: Any, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)
