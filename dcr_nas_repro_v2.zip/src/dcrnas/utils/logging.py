from __future__ import annotations

import csv
import time
from pathlib import Path
from typing import Dict, Iterable, Optional

class CSVLogger:
    def __init__(self, path: str | Path, fieldnames: Iterable[str]):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.fieldnames = list(fieldnames)
        self._header_written = self.path.exists() and self.path.stat().st_size > 0

    def log(self, row: Dict):
        row = dict(row)
        row.setdefault("timestamp", time.time())
        write_header = not self._header_written
        with self.path.open("a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=self.fieldnames)
            if write_header:
                writer.writeheader()
                self._header_written = True
            writer.writerow(row)

def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p
