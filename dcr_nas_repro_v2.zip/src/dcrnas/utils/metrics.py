from __future__ import annotations

import math
from typing import Dict, Iterable, Tuple

import numpy as np
from scipy import stats

def kendall_tau(y_true, y_pred) -> float:
    return float(stats.kendalltau(y_true, y_pred).statistic)

def spearman_r(y_true, y_pred) -> float:
    return float(stats.spearmanr(y_true, y_pred).statistic)

def pearson_r(y_true, y_pred) -> float:
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    if y_true.std() == 0 or y_pred.std() == 0:
        return 0.0
    return float(np.corrcoef(y_true, y_pred)[0, 1])

def mse(y_true, y_pred) -> float:
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    return float(np.mean((y_true - y_pred) ** 2))

def mae(y_true, y_pred) -> float:
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    return float(np.mean(np.abs(y_true - y_pred)))

def rmse(y_true, y_pred) -> float:
    return math.sqrt(mse(y_true, y_pred))

def ndcg_at_k(y_true, y_pred, k: int = 10) -> float:
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    order = np.argsort(-y_pred)[:k]
    gains = y_true[order]
    discounts = 1.0 / np.log2(np.arange(2, len(gains) + 2))
    dcg = np.sum(gains * discounts)

    best_order = np.argsort(-y_true)[:k]
    best_gains = y_true[best_order]
    idcg = np.sum(best_gains * discounts)
    if idcg <= 1e-12:
        return 0.0
    return float(dcg / idcg)

def topk_hit_ratio(y_true, y_pred, k: int = 10) -> float:
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    pred_top = set(np.argsort(-y_pred)[:k].tolist())
    true_top = set(np.argsort(-y_true)[:k].tolist())
    if k == 0:
        return 0.0
    return float(len(pred_top & true_top) / k)

def ranking_summary(y_true, y_pred) -> Dict[str, float]:
    return {
        "kendall_tau": kendall_tau(y_true, y_pred),
        "spearman_r": spearman_r(y_true, y_pred),
        "pearson_r": pearson_r(y_true, y_pred),
        "mae": mae(y_true, y_pred),
        "rmse": rmse(y_true, y_pred),
        "ndcg@10": ndcg_at_k(y_true, y_pred, 10),
        "top10_hit": topk_hit_ratio(y_true, y_pred, 10),
    }
