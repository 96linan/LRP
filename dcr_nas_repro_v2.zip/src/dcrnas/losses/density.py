from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import torch
from scipy.stats import beta as beta_dist

@dataclass
class DensityConfig:
    bins: int = 20
    alpha0: float = 1.0
    q: float = 0.2
    gamma_reg: float = 1.5
    gamma_a: float = 1.5
    c_eta: float = 1.0
    wmin: float = 0.1
    wmax: float = 10.0
    eps: float = 1e-8
    mode: str = "dirichlet"

class DensityWeighter:
    def __init__(self, cfg: DensityConfig):
        self.cfg = cfg

    def _bin_edges(self, y: torch.Tensor):
        y_np = y.detach().cpu().numpy()
        y_min, y_max = float(np.min(y_np)), float(np.max(y_np))
        if abs(y_max - y_min) < 1e-12:
            y_max = y_min + 1e-6
        edges = np.linspace(y_min, y_max, self.cfg.bins + 1)
        return edges

    def _bin_indices(self, y: torch.Tensor, edges):
        y_np = y.detach().cpu().numpy()
        idx = np.digitize(y_np, edges[1:-1], right=False)
        idx = np.clip(idx, 0, self.cfg.bins - 1)
        return idx

    def _bin_masses(self, counts):
        counts = np.asarray(counts, dtype=np.float64)
        n = counts.sum()
        if self.cfg.mode == "uniform":
            probs = np.ones_like(counts) / len(counts)
            return probs
        if self.cfg.mode == "hist":
            probs = counts / max(n, 1.0)
            probs = np.maximum(probs, self.cfg.eps)
            probs = probs / probs.sum()
            return probs
        if self.cfg.mode == "dirichlet":
            probs = np.zeros_like(counts, dtype=np.float64)
            total_alpha = n + len(counts) * self.cfg.alpha0
            for i, c in enumerate(counts):
                a = c + self.cfg.alpha0
                b = total_alpha - a
                probs[i] = beta_dist.ppf(self.cfg.q, a, b)
            probs = np.maximum(probs, self.cfg.eps)
            probs = probs / probs.sum()
            return probs
        raise ValueError(f"Unknown density mode: {self.cfg.mode}")

    def compute(self, y: torch.Tensor):
        edges = self._bin_edges(y)
        bin_idx = self._bin_indices(y, edges)
        counts = np.bincount(bin_idx, minlength=self.cfg.bins)
        masses = self._bin_masses(counts)

        reg_w = (masses[bin_idx] + self.cfg.eps) ** (-self.cfg.gamma_reg)
        reg_w = np.clip(reg_w, self.cfg.wmin, self.cfg.wmax)

        anchor_eta = self.cfg.c_eta * (masses[bin_idx] + self.cfg.eps) ** (-self.cfg.gamma_a)
        anchor_eta = np.clip(anchor_eta, self.cfg.wmin, self.cfg.wmax)

        return {
            "bin_idx": torch.tensor(bin_idx, dtype=torch.long, device=y.device),
            "counts": torch.tensor(counts, dtype=torch.float32, device=y.device),
            "masses": torch.tensor(masses, dtype=torch.float32, device=y.device),
            "reg_w": torch.tensor(reg_w, dtype=torch.float32, device=y.device),
            "anchor_eta": torch.tensor(anchor_eta, dtype=torch.float32, device=y.device),
            "edges": edges,
        }
