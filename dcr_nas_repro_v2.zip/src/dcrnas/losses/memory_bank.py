from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import torch

@dataclass
class BankState:
    z: torch.Tensor
    y: torch.Tensor
    yhat: torch.Tensor

class MemoryBank:
    def __init__(self, max_size: int = 1024):
        self.max_size = int(max_size)
        self.z = None
        self.y = None
        self.yhat = None

    def reset(self):
        self.z = None
        self.y = None
        self.yhat = None

    def __len__(self):
        return 0 if self.z is None else int(self.z.shape[0])

    def enqueue(self, z: torch.Tensor, y: torch.Tensor, yhat: torch.Tensor):
        z = z.detach()
        y = y.detach()
        yhat = yhat.detach()
        if self.z is None:
            self.z, self.y, self.yhat = z, y, yhat
        else:
            self.z = torch.cat([self.z, z], dim=0)[-self.max_size :]
            self.y = torch.cat([self.y, y], dim=0)[-self.max_size :]
            self.yhat = torch.cat([self.yhat, yhat], dim=0)[-self.max_size :]

    def get(self) -> Optional[BankState]:
        if self.z is None:
            return None
        return BankState(z=self.z, y=self.y, yhat=self.yhat)
