from __future__ import annotations

import torch
import torch.nn.functional as F

def weighted_huber_loss(yhat: torch.Tensor, y: torch.Tensor, w: torch.Tensor, delta: float = 1.0):
    raw = F.huber_loss(yhat, y, reduction="none", delta=delta)
    weighted = raw * w
    return weighted.mean()
