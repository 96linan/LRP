from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple

import torch
import torch.nn.functional as F

from dcrnas.losses.memory_bank import MemoryBank

@dataclass
class DCRConfig:
    temperature: float = 0.1
    rho_y: float = 0.3
    rho_yhat: float = 0.3
    pair_mode: str = "quantile"
    bank_size: int = 1024

class DCRLoss:
    def __init__(self, cfg: DCRConfig):
        self.cfg = cfg
        self.bank = MemoryBank(cfg.bank_size)

    def reset_bank(self):
        self.bank.reset()

    def _candidate_pool(self, z, y, yhat):
        bank = self.bank.get()
        if bank is None:
            return z, y, yhat
        return (
            torch.cat([z, bank.z.to(z.device)], dim=0),
            torch.cat([y, bank.y.to(y.device)], dim=0),
            torch.cat([yhat, bank.yhat.to(yhat.device)], dim=0),
        )

    def _quantile(self, values: torch.Tensor, q: float):
        if values.numel() == 0:
            return torch.tensor(0.0, device=values.device)
        return torch.quantile(values, q)

    def _pair_sets(self, z_pool, y_pool, yhat_pool, anchor_idx: int):
        yj = y_pool[anchor_idx]
        yhatj = yhat_pool[anchor_idx]

        dy = torch.abs(y_pool - yj)
        dyhat = torch.abs(yhat_pool - yhatj)

        if self.cfg.pair_mode == "quantile":
            delta_y = self._quantile(dy, self.cfg.rho_y)
            delta_yhat = self._quantile(dyhat, self.cfg.rho_yhat)
            pos = dy <= delta_y
            neg = (dy > delta_y) & (dyhat <= delta_yhat)
        elif self.cfg.pair_mode == "fixed":
            pos = dy <= 0.05
            neg = (dy > 0.10) & (dyhat <= 0.05)
        elif self.cfg.pair_mode == "random":
            n = len(dy)
            perm = torch.randperm(n, device=dy.device)
            pos = torch.zeros(n, dtype=torch.bool, device=dy.device)
            neg = torch.zeros(n, dtype=torch.bool, device=dy.device)
            pos[perm[: max(1, n // 8)]] = True
            neg[perm[max(1, n // 8): max(2, n // 4)]] = True
            pos[anchor_idx] = True
            neg[anchor_idx] = False
        else:
            raise ValueError(f"Unknown pair mode: {self.cfg.pair_mode}")

        pos[anchor_idx] = True
        neg[anchor_idx] = False
        return pos, neg

    def __call__(self, z_a, z_b, y, yhat_a, anchor_eta):
        z = torch.cat([z_a, z_b], dim=0)
        y2 = torch.cat([y, y], dim=0)
        yhat2 = torch.cat([yhat_a, yhat_a], dim=0)
        eta2 = torch.cat([anchor_eta, anchor_eta], dim=0)

        z_pool, y_pool, yhat_pool = self._candidate_pool(z, y2, yhat2)
        z_norm = F.normalize(z_pool, dim=-1)
        local_z = F.normalize(z, dim=-1)

        losses = []
        B = z.shape[0]
        for j in range(B):
            pos_mask, neg_mask = self._pair_sets(z_pool, y_pool, yhat_pool, j)

            pos_idx = torch.where(pos_mask)[0]
            neg_idx = torch.where(neg_mask)[0]
            if neg_idx.numel() == 0 or pos_idx.numel() == 0:
                continue

            sim_all = torch.exp(torch.matmul(z_norm, local_z[j]) / self.cfg.temperature)
            pos_scores = sim_all[pos_idx]

            neg_scores = sim_all[neg_idx]
            neg_weights = eta2[j] * torch.abs(y_pool[neg_idx] - y2[j])
            denom = pos_scores.sum() + (neg_scores * neg_weights).sum()
            numer = pos_scores.mean()
            loss_j = -torch.log((numer + 1e-12) / (denom + 1e-12))
            losses.append(loss_j)

        self.bank.enqueue(z.detach(), y2.detach(), yhat2.detach())
        if not losses:
            return torch.tensor(0.0, device=z.device)
        return torch.stack(losses).mean()
