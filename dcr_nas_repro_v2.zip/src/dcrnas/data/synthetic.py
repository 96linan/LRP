from __future__ import annotations

import math
from typing import Dict, List, Tuple

import numpy as np
import torch

from dcrnas.data.base import GraphDataset, GraphRecord

OPS = [
    "input",
    "conv1x1",
    "conv3x3",
    "maxpool3x3",
    "skip",
    "avgpool3x3",
    "output",
]

def _random_dag(num_nodes: int, p: float, rng: np.random.Generator):
    adj = np.zeros((num_nodes, num_nodes), dtype=np.float32)
    for i in range(num_nodes):
        for j in range(i + 1, num_nodes):
            if rng.random() < p:
                adj[i, j] = 1.0
    # ensure at least one path-ish structure
    for i in range(num_nodes - 1):
        adj[i, i + 1] = 1.0
    return adj

def _node_features(num_nodes: int, feat_dim: int, rng: np.random.Generator):
    x = rng.normal(size=(num_nodes, feat_dim)).astype(np.float32)
    return x

def _graph_score(adj: np.ndarray, x: np.ndarray):
    edge_count = adj.sum()
    depth_bias = sum((j - i) * adj[i, j] for i in range(adj.shape[0]) for j in range(adj.shape[1]))
    feature_strength = float(np.abs(x).mean())
    path_bonus = float((adj.sum(axis=0) > 0).sum())
    score = (
        0.018 * edge_count
        + 0.007 * depth_bias
        + 0.11 * feature_strength
        + 0.012 * path_bonus
    )
    return score

def _long_tail_transform(score: float, imbalance_strength: float):
    # compress the high end to create dense head + sparse tail
    return 1.0 - math.exp(-imbalance_strength * max(score, 0.0) / 10.0)

def generate_synthetic_graph_records(
    n: int,
    num_nodes: int,
    node_feat_dim: int,
    imbalance_strength: float = 3.5,
    noise_std: float = 0.03,
    feature_shift: float = 0.0,
    with_eval_target: bool = True,
    seed: int = 42,
) -> List[Dict]:
    rng = np.random.default_rng(seed)
    records = []
    for idx in range(n):
        p = float(np.clip(rng.beta(2.0, 6.0), 0.05, 0.8))
        adj = _random_dag(num_nodes, p, rng)
        x = _node_features(num_nodes, node_feat_dim, rng) + feature_shift
        base = _graph_score(adj, x)
        y = _long_tail_transform(base, imbalance_strength)
        y = y + rng.normal(scale=noise_std)
        y = float(np.clip(y, 0.0, 1.0))
        test_y = y
        if with_eval_target:
            test_y = float(np.clip(y + rng.normal(scale=noise_std * 0.5), 0.0, 1.0))
        records.append(
            {
                "adj": adj.tolist(),
                "node_features": x.tolist(),
                "y": y,
                "test_y": test_y,
                "id": f"syn_{idx:06d}",
            }
        )
    return records

def build_synthetic_splits(cfg: Dict):
    ds_cfg = cfg["dataset"]
    seed = cfg.get("seed", 42)
    feat_shift = 0.0

    train = generate_synthetic_graph_records(
        n=ds_cfg["train_size"],
        num_nodes=ds_cfg["num_nodes"],
        node_feat_dim=ds_cfg["node_feat_dim"],
        imbalance_strength=ds_cfg.get("imbalance_strength", 3.5),
        noise_std=ds_cfg.get("noise_std", 0.03),
        feature_shift=feat_shift,
        seed=seed,
    )
    valid = generate_synthetic_graph_records(
        n=ds_cfg["valid_size"],
        num_nodes=ds_cfg["num_nodes"],
        node_feat_dim=ds_cfg["node_feat_dim"],
        imbalance_strength=ds_cfg.get("imbalance_strength", 3.5),
        noise_std=ds_cfg.get("noise_std", 0.03),
        feature_shift=feat_shift,
        seed=seed + 1,
    )
    test = generate_synthetic_graph_records(
        n=ds_cfg["test_size"],
        num_nodes=ds_cfg["num_nodes"],
        node_feat_dim=ds_cfg["node_feat_dim"],
        imbalance_strength=ds_cfg.get("imbalance_strength", 3.5),
        noise_std=ds_cfg.get("noise_std", 0.03),
        feature_shift=feat_shift,
        seed=seed + 2,
    )

    alt_tests = {}
    for i, spec in enumerate(ds_cfg.get("alternate_test_sets", [])):
        alt_tests[spec["name"]] = generate_synthetic_graph_records(
            n=ds_cfg["test_size"],
            num_nodes=ds_cfg["num_nodes"],
            node_feat_dim=ds_cfg["node_feat_dim"],
            imbalance_strength=ds_cfg.get("imbalance_strength", 3.5),
            noise_std=spec.get("noise_std", ds_cfg.get("noise_std", 0.03)),
            feature_shift=spec.get("feature_shift", 0.0),
            seed=seed + 100 + i,
        )

    return (
        records_to_dataset(train, target_key="y", eval_key="test_y"),
        records_to_dataset(valid, target_key="y", eval_key="test_y"),
        records_to_dataset(test, target_key="y", eval_key="test_y"),
        {k: records_to_dataset(v, target_key="y", eval_key="test_y") for k, v in alt_tests.items()},
    )

def records_to_dataset(records: List[Dict], target_key="y", eval_key="test_y") -> GraphDataset:
    out = []
    for item in records:
        out.append(
            GraphRecord(
                adj=torch.tensor(item["adj"], dtype=torch.float32),
                node_features=torch.tensor(item["node_features"], dtype=torch.float32),
                y=float(item[target_key]),
                eval_y=float(item.get(eval_key, item[target_key])),
                sample_id=item.get("id"),
            )
        )
    return GraphDataset(out)
