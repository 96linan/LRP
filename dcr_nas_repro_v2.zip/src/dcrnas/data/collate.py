from __future__ import annotations

from typing import List, Dict, Any
import torch

def collate_graphs(batch: List[Dict[str, Any]]) -> Dict[str, Any]:
    max_nodes = max(item["adj"].shape[0] for item in batch)
    feat_dim = batch[0]["node_features"].shape[1]

    adjs, feats, masks, y, eval_y, ids = [], [], [], [], [], []
    for item in batch:
        n = item["adj"].shape[0]
        pad_adj = torch.zeros(max_nodes, max_nodes, dtype=torch.float32)
        pad_adj[:n, :n] = item["adj"]

        pad_feat = torch.zeros(max_nodes, feat_dim, dtype=torch.float32)
        pad_feat[:n] = item["node_features"]

        mask = torch.zeros(max_nodes, dtype=torch.float32)
        mask[:n] = 1.0

        adjs.append(pad_adj)
        feats.append(pad_feat)
        masks.append(mask)
        y.append(item["y"])
        eval_y.append(item["eval_y"])
        ids.append(item["id"])

    return {
        "adj": torch.stack(adjs, dim=0),
        "node_features": torch.stack(feats, dim=0),
        "mask": torch.stack(masks, dim=0),
        "y": torch.stack(y, dim=0),
        "eval_y": torch.stack(eval_y, dim=0),
        "id": ids,
    }
