from __future__ import annotations

from typing import Dict, Tuple
import numpy as np

from dcrnas.data.synthetic import records_to_dataset
from dcrnas.utils.io import load_any

def build_nasbench_like_splits(cfg: Dict):
    ds_cfg = cfg["dataset"]
    records = load_any(ds_cfg["path"])

    n = len(records)
    rng = np.random.default_rng(cfg.get("seed", 42))
    idx = np.arange(n)
    rng.shuffle(idx)

    train_ratio = ds_cfg.get("train_ratio", 0.15)
    valid_ratio = ds_cfg.get("valid_ratio", 0.10)
    train_end = int(n * train_ratio)
    valid_end = train_end + int(n * valid_ratio)

    train_rec = [records[i] for i in idx[:train_end]]
    valid_rec = [records[i] for i in idx[train_end:valid_end]]
    test_rec = [records[i] for i in idx[valid_end:]]

    target_key = ds_cfg.get("target_key", "y")
    eval_key = ds_cfg.get("eval_target_key", target_key)

    train_ds = records_to_dataset(train_rec, target_key=target_key, eval_key=eval_key)
    valid_ds = records_to_dataset(valid_rec, target_key=target_key, eval_key=eval_key)
    test_ds = records_to_dataset(test_rec, target_key=target_key, eval_key=eval_key)
    return train_ds, valid_ds, test_ds, {}
