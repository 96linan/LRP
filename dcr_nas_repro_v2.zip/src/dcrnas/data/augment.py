from __future__ import annotations

import torch

def augment_graph_batch(adj, node_features, mask, edge_drop_prob=0.1, feat_mask_prob=0.1):
    device = adj.device
    B, N, _ = adj.shape
    out_adj = adj.clone()
    out_feat = node_features.clone()

    if edge_drop_prob > 0:
        drop_mask = (torch.rand_like(out_adj) < edge_drop_prob).float()
        eye = torch.eye(N, device=device).unsqueeze(0)
        drop_mask = drop_mask * (1 - eye)
        out_adj = out_adj * (1 - drop_mask)
        out_adj = torch.maximum(out_adj, out_adj.transpose(1, 2))

    if feat_mask_prob > 0:
        fm = (torch.rand_like(out_feat) < feat_mask_prob).float()
        out_feat = out_feat * (1 - fm)

    out_feat = out_feat * mask.unsqueeze(-1)
    out_adj = out_adj * mask.unsqueeze(1) * mask.unsqueeze(2)
    return out_adj, out_feat
