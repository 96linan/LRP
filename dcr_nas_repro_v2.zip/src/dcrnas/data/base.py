from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

import torch
from torch.utils.data import Dataset

@dataclass
class GraphRecord:
    adj: torch.Tensor
    node_features: torch.Tensor
    y: float
    eval_y: float | None = None
    sample_id: str | None = None

class GraphDataset(Dataset):
    def __init__(self, records: List[GraphRecord]):
        self.records = records

    def __len__(self):
        return len(self.records)

    def __getitem__(self, index: int) -> Dict[str, Any]:
        rec = self.records[index]
        return {
            "adj": rec.adj.float(),
            "node_features": rec.node_features.float(),
            "y": torch.tensor(rec.y, dtype=torch.float32),
            "eval_y": torch.tensor(rec.eval_y if rec.eval_y is not None else rec.y, dtype=torch.float32),
            "id": rec.sample_id if rec.sample_id is not None else str(index),
        }
