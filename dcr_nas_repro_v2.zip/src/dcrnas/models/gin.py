from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

class GINLayer(nn.Module):
    def __init__(self, hidden_dim: int, dropout: float = 0.1, learn_eps: bool = True):
        super().__init__()
        self.eps = nn.Parameter(torch.zeros(1)) if learn_eps else 0.0
        self.mlp = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.bn = nn.BatchNorm1d(hidden_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, adj, mask):
        agg = torch.bmm(adj, x)
        if isinstance(self.eps, torch.Tensor):
            out = (1 + self.eps) * x + agg
        else:
            out = (1 + self.eps) * x + agg
        out = self.mlp(out)
        B, N, H = out.shape
        out = out.reshape(B * N, H)
        out = self.bn(out)
        out = out.reshape(B, N, H)
        out = F.relu(out)
        out = self.dropout(out)
        out = out * mask.unsqueeze(-1)
        return out

class LightGINPredictor(nn.Module):
    def __init__(self, node_feat_dim: int, hidden_dim: int = 128, num_layers: int = 4, dropout: float = 0.1, regression_hidden: int = 128):
        super().__init__()
        self.input_proj = nn.Linear(node_feat_dim, hidden_dim)
        self.layers = nn.ModuleList([GINLayer(hidden_dim, dropout=dropout) for _ in range(num_layers)])
        self.head = nn.Sequential(
            nn.Linear(hidden_dim, regression_hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(regression_hidden, 1),
        )

    def encode(self, adj, node_features, mask):
        x = self.input_proj(node_features)
        x = x * mask.unsqueeze(-1)
        for layer in self.layers:
            x = layer(x, adj, mask)
        pooled = x.sum(dim=1)
        return pooled

    def forward(self, adj, node_features, mask):
        z = self.encode(adj, node_features, mask)
        yhat = self.head(z).squeeze(-1)
        return z, yhat
