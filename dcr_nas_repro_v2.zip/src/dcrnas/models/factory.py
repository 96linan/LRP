from __future__ import annotations

from dcrnas.models.mlp import FlatGraphPredictor
from dcrnas.models.gin import LightGINPredictor

def build_model(cfg, sample_batch):
    model_cfg = cfg["model"]
    backbone = model_cfg.get("backbone", "gin")
    _, max_nodes, feat_dim = sample_batch["node_features"].shape

    if backbone == "mlp":
        return FlatGraphPredictor(
            num_nodes=max_nodes,
            feat_dim=feat_dim,
            hidden_dim=model_cfg.get("hidden_dim", 128),
            dropout=model_cfg.get("dropout", 0.1),
        )
    if backbone == "gin":
        return LightGINPredictor(
            node_feat_dim=feat_dim,
            hidden_dim=model_cfg.get("hidden_dim", 128),
            num_layers=model_cfg.get("num_layers", 4),
            dropout=model_cfg.get("dropout", 0.1),
            regression_hidden=model_cfg.get("regression_hidden", 128),
        )
    raise ValueError(f"Unknown backbone: {backbone}")
