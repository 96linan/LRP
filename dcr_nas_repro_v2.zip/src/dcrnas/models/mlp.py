from __future__ import annotations

import torch
import torch.nn as nn

class MLPBackbone(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int = 128, dropout: float = 0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
        )

    def forward(self, x):
        return self.net(x)

class FlatGraphPredictor(nn.Module):
    def __init__(self, num_nodes: int, feat_dim: int, hidden_dim: int = 128, dropout: float = 0.1):
        super().__init__()
        input_dim = num_nodes * num_nodes + num_nodes * feat_dim
        self.backbone = MLPBackbone(input_dim, hidden_dim=hidden_dim, dropout=dropout)
        self.head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 1),
        )

    def encode(self, adj, node_features, mask):
        flat = torch.cat([adj.flatten(1), node_features.flatten(1)], dim=1)
        return self.backbone(flat)

    def forward(self, adj, node_features, mask):
        z = self.encode(adj, node_features, mask)
        yhat = self.head(z).squeeze(-1)
        return z, yhat
