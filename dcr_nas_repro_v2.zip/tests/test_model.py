import torch
from dcrnas.models.gin import LightGINPredictor

def test_model_forward():
    model = LightGINPredictor(node_feat_dim=8, hidden_dim=16, num_layers=2)
    adj = torch.randint(0, 2, (4, 7, 7)).float()
    adj = torch.triu(adj, diagonal=1)
    x = torch.randn(4, 7, 8)
    mask = torch.ones(4, 7)
    z, yhat = model(adj, x, mask)
    assert z.shape == (4, 16)
    assert yhat.shape == (4,)
