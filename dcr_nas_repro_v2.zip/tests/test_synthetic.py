from dcrnas.data.synthetic import generate_synthetic_graph_records

def test_synthetic_generation():
    recs = generate_synthetic_graph_records(10, 7, 8)
    assert len(recs) == 10
    assert "adj" in recs[0]
    assert "node_features" in recs[0]
    assert "y" in recs[0]
