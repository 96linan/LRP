import torch
from dcrnas.losses.dcr import DCRConfig, DCRLoss

def test_dcr_runs():
    loss_fn = DCRLoss(DCRConfig())
    z_a = torch.randn(8, 16)
    z_b = torch.randn(8, 16)
    y = torch.rand(8)
    yhat = torch.rand(8)
    eta = torch.ones(8)
    loss = loss_fn(z_a, z_b, y, yhat, eta)
    assert torch.isfinite(loss)
