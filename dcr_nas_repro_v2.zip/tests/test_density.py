import torch
from dcrnas.losses.density import DensityConfig, DensityWeighter

def test_density_shapes():
    cfg = DensityConfig(bins=10, mode="dirichlet")
    w = DensityWeighter(cfg)
    y = torch.tensor([0.1, 0.2, 0.8, 0.9], dtype=torch.float32)
    out = w.compute(y)
    assert out["reg_w"].shape[0] == 4
    assert out["anchor_eta"].shape[0] == 4
    assert out["masses"].shape[0] == 10
