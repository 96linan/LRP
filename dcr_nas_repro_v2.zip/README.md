# DCR-NAS Reproduction Repository

A real multi-file reproduction-oriented codebase for the paper:

**Overcoming Imbalanced Bias in Neural Predictor: A Distribution-aware Contrastive Regularizer Approach**

## What is included

- Graph predictor backbones (MLP and lightweight dense-adjacency GIN)
- Distribution-aware contrastive regularizer (DCR)
- Dirichlet-LCB / histogram / uniform density weighting
- FIFO memory bank
- Weighted Huber regression
- Synthetic imbalanced NAS-like datasets
- NASBench-style JSON/pickle dataset adapter
- Ranking evaluation (Kendall / Spearman / Pearson / NDCG@k / top-k hit)
- Main training and evaluation scripts
- Ablation runner for:
  - pair construction
  - density weighting
  - gamma_a
  - q quantile
- Simple evolutionary search demo on a candidate pool
- Tests for core modules

## Repository layout

```text
src/dcrnas/
  config.py
  trainer.py
  utils/
  data/
  models/
  losses/
  search/
scripts/
configs/
tests/
```

## Quick start

```bash
pip install -r requirements.txt
export PYTHONPATH=src

python scripts/train.py --config configs/synth_main.yaml
python scripts/eval_ranking.py --config configs/synth_main.yaml --checkpoint outputs/synth_main/best.pt
python scripts/run_ablation.py --config configs/synth_main.yaml --ablation pair_mode
python scripts/search_demo.py --config configs/synth_main.yaml --checkpoint outputs/synth_main/best.pt
```

## Notes

1. This repo is executable end-to-end on synthetic imbalanced NAS-like datasets out of the box.
2. For NASBench-style experiments, place a dataset file at the configured path. Supported format:
   - `.json` list of dicts
   - `.pkl` list of dicts

Each sample must contain:

```python
{
  "adj": [[...], [...], ...],      # adjacency matrix
  "node_features": [[...], ...],   # node feature matrix
  "y": 91.23,                      # target (e.g. validation accuracy)
  "test_y": 92.11,                 # optional alternative evaluation target
  "id": "arch_001"                 # optional id
}
```

## Honesty note

This package is a serious, executable reproduction-oriented codebase with many files and real implementations. It is **not** a verified claim of matching every paper number on NASBench-101 / NASBench-201 / DARTS in this environment, because the benchmark data and heavy runs are not available here.
